<?php
  header("HTTP/1.0 404 Not Found");
?>

<div style="height:calc(100vh - 2rem);display:flex;justify-content:center;align-items:center;flex-direction:column;">
   <h1 style="font-size:100px;">404 Error</h1>
   <p style="font-size:30px;">Something is Wrong</p>
</div>