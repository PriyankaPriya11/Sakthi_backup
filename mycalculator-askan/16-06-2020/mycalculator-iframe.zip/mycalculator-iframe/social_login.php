<?php
    class SocialLogin {
        private $clientId = "310141663690-eou66jgv6ae79jv69hqrpmv8k401n6uj.apps.googleusercontent.com";
        private $clientSecret = "r8ikhdgi3KumvQLz_AZgjN6g";
    }
?>